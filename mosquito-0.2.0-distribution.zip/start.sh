#!/bin/bash
java $2 -cp "mosquito-0.2.0.jar;lib/*" de.uni_leipzig.mosquito.benchmark.Benchmark $1
