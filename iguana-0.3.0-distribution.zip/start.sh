java $2 -cp "lib/*" de.uni_leipzig.iguana.benchmark.Main $1
