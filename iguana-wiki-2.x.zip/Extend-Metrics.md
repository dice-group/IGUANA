To extend a Metric you only have to implement the logic of your desired Metric.

Create your Metric class as follows: 
```java
package org.example.mymetrics;

import org.aksw.iguana.commons.constants.COMMON;
import org.aksw.iguana.rp.data.Triple;
import org.aksw.iguana.rp.metrics.AbstractMetric;

public class MyMetric extends AbstractMetric {

    public MyMetric() {
	super("My Metric", "Short Name to save into TripleStore",
	   "Description.");
    }
...
}
```

The short name will be used to create a link between the task and the actual results. If you use MyMetric for example. 
you can reach your metric with the sparql query
```sparql
SELECT * {?taskID iguana:MyMetric ?results}
```

Now we will add the Logic begind the Metric.

```java
...
    @Override
    public void receiveData(Properties p) {
        //Add your Logic here. We use the NoQPH example
        long time = (long) p.get(COMMON.RECEIVE_DATA_TIME);
	Integer success = (Boolean) p.get(COMMON.RECEIVE_DATA_SUCCESS)?1:0;	
		
        //create your own temporary results
	Properties results = new Properties();
	results.put(TOTAL_TIME, time);
	results.put(TOTAL_SUCCESS, success);
        
        //This will save the results using the extraMeta as a reference point 
        //This is needed if you want to diverge between different Workers
        Properties extra = getExtraMeta(p);
	processData(extra, results);

    }
```

Finally you have to send the data to the storages. This is quite easy. You could also send your results in the receive method if you do not have to save them.

```java
    @Override
    public void close() {
        // for each worker
        for(Properties key : dataContainer.keySet()){
            //calculate your metric, we will take NoQPH again
	    Long totalTime = (Long) dataContainer.get(key).get(TOTAL_TIME);
	    Integer success = (Integer) dataContainer.get(key).get(TOTAL_SUCCESS);
	    Double noOfQueriesPerHour = hourInMS*success*1.0/totalTime;
     
            //create your final results
	    Properties results = new Properties();
	    results.put("noOfQueriesPerHour", noOfQueriesPerHour);
            //send the results. Thats it
	    sendTriples(results, key);
	}	
    }
```