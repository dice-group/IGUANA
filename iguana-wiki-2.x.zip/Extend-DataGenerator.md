The Data Generator will create Data into a jena Model and then will send the data to the LoaderManager.
The Loader manager then will add your data into the triplestore.

To add a Data Generator pleas create the following class

```java
package org.example.data;

import org.aksw.iguana.dg.generator.AbstractDataGenerator;

public class MyDataGenerator extend AbstractDataGenerator{

    public MyDataGenerator(String arg1, String arg2){
          // add as many or less String arguments as you want. The Iguana config will have to add them.
    }

    public void init(){
          //TODO: add what ever you need to be initialized
    }
}
```

Further on you just need to implement one mehtod. The generate Method.

```java
	/**
	 * This method should generate your data,</br></br>
	 * 
	 * to make use of the underlying abstract class, please add your data to the data Model
	 * or elsewise make use of the sendDataSnippet(byte[]) or sendDataComplete(Model) methods.
	 * If you add your data to the Model data. You do not have to send it. It will be sended
	 * as soon the generate() method stops.</br></br>
	 * 
	 * if your model is too big though, you can send snippets of the dataset
	 * 
	 * you can use the sendData(Model) method for this still. </br>
	 * It will automatically send the model in the accurate size of blocks to the controller.
	 */
	public abstract void generate() throws Exception{
           List<Statements> stmts = new LinkedList<Statements>();

           //TODO generate your data

           //add your statements to the model 
           this.data.add(stmts); 
        }
```

Thats it.