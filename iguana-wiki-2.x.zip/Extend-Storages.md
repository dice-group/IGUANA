There are two different ways to create a Storage. The first one is to use a triple based storage. 
This is quite easy, as most of the logic is already implemented.
The other Option would be to  implement the interface yourself.


### TripleBased Storage implementation

To create a Triple based Storage create a class like follows:
```java
/**
 * 
 */
package org.example.storage.MyStorage;

import org.aksw.iguana.rp.storage.TripleBasedStorage;


public class MyStorage extends TripleBasedStorage {

    public MyStorage(String arg1,String arg2){
       //You can add as many String arguments as you want
       //The Iguana.properties will have to solve this (so you have to configure it in the
       // result processor configuration properties file)
    }
}
```

Now you have to implement only two more methods. The first one will tell where your storage is located. Is it a file? Where is it located, is it a triple store, whats the endpoint etc. 
```java
	@Override
	public Properties getStorageInfo() {
		Properties ret = new Properties();
		//add your storage info to the properties
		return ret;
	}
```


The other method is the commit method. This method should be used to send the current results to your storage container (or wherever you want to save the results)
```java
	@Override
	public void commit() {
		//the blockUpdate is StringBuilder with triples in it. (it looks like a ntriples file)
		if(blockUpdate.length()==0){
			return;
		}
		//TODO: Here you have to add the triples in the blockUpdate to your storage

                //empty the already commited triples
		blockUpdate =  new StringBuilder();
	}
```

### Storage implementation

This implementation is a bit trickier, as no logic is implemented. Thus you have to add  a little bit more code.
Lets begin with the class
```java
package org.example.storage.MyStorage;

import org.aksw.iguana.rp.storage.Storage;

public class MyStorage implements Storage {
   
   public MyStorage(String arg1,String arg2){
       //You can add as many String arguments as you want
       //The Iguana.properties will have to solve this (so you have to configure it in the
       // result processor configuration properties file)
    }
}
```

Now you must add the Storage Information.
This will tell where your storage is located. Is it a file? Where is it located, is it a triple store, whats the endpoint etc. 
```java
	@Override
	public Properties getStorageInfo() {
		Properties ret = new Properties();
		//add your storage info to the properties
		return ret;
	}
```

and again the commit method
 This method should be used to send the current results to your storage container (or wherever you want to save the results)
```java
	@Override
	public void commit() {
		//the blockUpdate is StringBuilder with triples in it. (it looks like a ntriples file)
		if(blockUpdate.length()==0){
			return;
		}
		//TODO: Here you have to add the triples in the blockUpdate to your storage

                //empty the already commited triples
		blockUpdate =  new StringBuilder();
	}
```

Further on you have to receive the result data as well as the meta data yourself.
You can do this by adding the following two methods
```java
        /**
	 * Add actual result data from metrics
	 * @param meta the meta data (metric, experimentID,...)
	 * @param data the actual data to add
	 */
	public void addData(Properties meta, Triple[] data){
             String taskID = meta.getProperty(COMMON.EXPERIMENT_TASK_ID_KEY);
             Integer extraLength = (Integer) meta.get(CONSTANTS.LENGTH_EXTRA_META_KEY);
             String metric = meta.get(COMMON.METRICS_PROPERTIES_KEY);

             //TODO. add your data however you want. 

             //You do not have to add the commit method here! It will be execcuted for you. 
             //If you want to save the data right away, leave the commit method empty and do it here
        }
	
	/**
	 * Add meta data from the experiment task
	 * for example: Query ID and Query text, ExperimentID, WorkerID,...
	 * 
	 * @param p
	 */
	public void addMetaData(Properties p){
            String suiteId = p.getProperty(COMMON.SUITE_ID_KEY);
            String expId = p.getProperty(COMMON.EXPERIMENT_ID_KEY);
            String taskId = p.getProperty(COMMON.EXPERIMENT_TASK_ID_KEY);
            String connId = p.getProperty(COMMON.CONNECTION_ID_KEY);      
            String extraMeta = p.getProperty(COMMON.EXTRA_META_KEY); 
    
            //TODO. add your meta data however you want. 




            //You do not have to add the commit method here! It will be execcuted for you
            //If you want to save the data right away, leave the commit method empty and do it here
        }
```