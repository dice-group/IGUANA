Iguana is seperated into three main modules. 
* The Core Module
* The Result processing Module
* and the Web Frontend
[![Architecture Overview](https://s1.postimg.org/5f5yh6oxrj/overview_version2.png)](https://postimg.org/image/16qr7cyoyz/)
Iguana works with RabbitMQ as a messanger between the modules. 

The Core controller will execute the data generation and executes the tasks, whereas the Result processor receives every executed query for every task and will save the results according to the metrics (KPIs) provided. 

The web Frontend can be used to create and send a configuration, see results of a current task live and/or search the results via SPARQL and create Bar as well as Line Charts.

> It is important to note, that the Result Processing Module as well as the Web Frontend should be started on a different Server then the actual core and triple stores to test. 
This has the advantage that the main RAM usage (the result processing) will not affect the performance of the triplestores. 

Further on Iguana is programmed generic and almost everything is programmed to be easily extendable

For further Information checkout the Modules
* [Core](https://github.com/AKSW/IGUANA/wiki/core)
* [Result Processing](https://github.com/AKSW/IGUANA/wiki/result_processing)
* [Web Frontend](https://github.com/AKSW/IGUANA/wiki/web)