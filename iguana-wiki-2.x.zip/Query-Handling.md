You can either use Query Instances, which are basically fully working queries or patterns. 
Patterns are handled the same way in the DBPSB 2012 

```sparql
SELECT * {?s dbr:label %%var1%%} 
```

Using a refernce connection, e.g. DBpedia the query pattern will be filled
and the output will be queries of the form 
```sparql
SELECT * {?s dbr:label "Fritz"}

SELECT * {?s dbr:label "Emma"}

SELECT * {?s dbr:label "Manu"}
```
....

The default limit is 2000