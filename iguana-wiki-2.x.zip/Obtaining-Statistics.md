To obtain statistics you need to play around with SPARQL, the IGUANA results and another statistics tool of your choice (such as Gnumeric or LibreOffice Calc)
Depending on what you want to obtain you can follow the next steps

1. Create the SPARQL Query you need
2. Query the results
3. Copy the results to the tool
4. Use their statistics 

We will go through these steps by using MSpQ (MicroSeconds per Query: How long does one query need in average) as an example.

## 1. Create the SPARQL query you need
To create our query we need the following data:
* The desired Suite and Task ID 
* The totalTime for each Query
* The amount of successfull runs for each Query

In the MSpQ case the query would look like this:
```
SELECT ?connection ?queryID (SUM(DISTINCT ?totaltime)/SUM(DISTINCT ?succ) AS ?mspq)
{
 <http://iguana-benchmark.eu/recource/61/1> <http://iguana-benchmark.eu/properties/dataset>  ?dataset . 
 <http://iguana-benchmark.eu/recource/61/1/1> <http://iguana-benchmark.eu/properties/connection> ?connection.
 <http://iguana-benchmark.eu/recource/61/1/1> ?p ?uuid . 
 ?uuid <http://iguana-benchmark.eu/properties/qps#query> ?query . 
 ?query <http://iguana-benchmark.eu/properties/queryID> ?queryID . 
 ?query <http://iguana-benchmark.eu/properties/totalTime> ?totaltime .
  ?query <http://iguana-benchmark.eu/properties/succeded> ?succ.
}
GROUP BY ?dataset ?connection ?queryID
ORDER BY ?mspq
```

Be aware of the `SUM DISTINCT` this is really important for two reasins. 
1. Without the sum the SPARQL endpoint cannot use totaltime and success as an `xsd:integer` but without the DISTINCT it may calculate more than the average if a result may was saved twice.
2. If several User were simulated the sum represents the actual average in total

```
SELECT distinct ?queryID (SUM(?queriesPerSecond) as ?qps)
WHERE {
SELECT   distinct ?query  ?queryID ?queriesPerSecond
{
 <http://iguana-benchmark.eu/recource/137/1/2> ?p ?uuid . 
 ?uuid <http://iguana-benchmark.eu/properties/qps#query> ?query . 
 ?query <http://iguana-benchmark.eu/properties/queryID> ?queryID . 
 ?query <http://iguana-benchmark.eu/properties/queriesPerSecond> ?queriesPerSecond .
}
}
GROUP BY ?queryID
ORDER BY ?queryID
```


## 2. Query the results
the results will then be spit out to your screen as a table.

## 3. Copy the results to the tool
Really straigth forward. Just copy the results to your tool. 
Copy the results to the tool

## 4. Use their statistics 
If copied you can use the data/statistics tool 
We will use LibreOffice Calc data **descriptive statistics** method.

1. Select only the MSpQ (so only the numbers)
2. Go to the TAB **Data/Statistics** and select **Descriptive Statistics...** 
3. Choose the location of the output.

The rest is up to you.