The core module will simply receive Iguana Configs and execute it. 

The more intereseting parts are the data generator and the task processor which are both included into the core. 

## Data Generator
The Data Generator will execute the data generation and will upload the generated data into the triple store using a provided Loader. This is currently not tested, but will be definite included in the next update including a data generator (v2.1) 

[![DG_workflow.jpg](https://s20.postimg.org/meh0ftokt/DG_workflow.jpg)](https://postimg.org/image/e8yyho0bt/)

## Task Processor
The Task Processor will generate a new ID for each Suite (Config) it receive. 
Further on it will generate an experiment ID and Task ID for each task 

F.e.:
One Iguana Config is one suite. A Suite ID is a simple integer (e.g. 8) 
this means your config is the 8th config which is executed against this Iguana instance. 

For each Dataset a new Experiment will be generated. 
The Experiment ID is build up as follows `suiteID/X` where as X is the Dataset Index. (If the second Dataset is executed X=2, if the first Dataset is executed X=1 and so on) 

At last the Task ID will be conclude out of the current Connection and the current Task. 
For ecample if the first connection and first task is executed the task ID is `suiteID/X/1` if the first connection and second task is exeecuted it will be `suiteID/X/2` and if the config has only two tasks, the second connection and first task will be then `suiteID/X/3` and so on.

This shows also in which order the tasks will be executed: for every Dataset, for every connection execute every Task.
[![TP_workflow.jpg](https://s20.postimg.org/j6cj34x9p/TP_workflow.jpg)](https://postimg.org/image/4zws7wmeh/)
