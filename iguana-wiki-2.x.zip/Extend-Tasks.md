To add a Task create a Class like follows

```java
package org.example.tasks.MyTask;

import org.aksw.iguana.tp.tasks.AbstractTask;

public class MyTask extends AbstractTask {

 	public MyTask(String[] ids, String[] services) {
		super(ids, services);
	}

	@Override
	public boolean isValid(Properties configuration) {
		return true;
	}

	@Override
	public void init(String host, String queueName) throws IOException, TimeoutException {
		super.init(host, queueName);  
                //This method will be called after the configuration is set and before execution
                //if you need something to do here, do it
	}

}
```

To receive your configuration add the following method. The Configuration will be build as same as the [Stresstest](stresstest) (in an abstract manner!).
You can use the same techniques to set the configuration in the Iguana Config and then receive this configuration.

```java
	@Override
	public void setConfiguration(Configuration taskConfig) {
            //This is an apache commons properties configuration. use it.
        }
```

If you want to add some meta data to the triple store you can do it with the following method
```java
	@Override
	public void addMetaData() {
		super.addMetaData();
		Properties extraMeta = new Properties();
                //Add your meta Data to extraMeta
		this.metaData.put(COMMON.EXTRA_META_KEY, extraMeta);
	}
```

Finally execute the Task 

```java
	@Override
	public void execute() { 
           //Whatever your tasks should do
        }
```


