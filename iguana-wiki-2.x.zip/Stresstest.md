### About
The Stresstest aims to simulate a real case scenario.
It tries to challenge the triple store by flooding it with as many queries and updates as possible from several Users.

This shows which triple store can handle an high amount of request by several users while updating over a specific amount of time and which not. 

The Stresstest can be completly configured and thus provides everything from a simple baseline with one user and only sparql queries to the worst nightmare of the developers, several sparql users all different but complex queries with different network latency and timeouts while several users try to update the triple store.

[![Stesstest_overview.jpg](https://s20.postimg.org/x931vzhsd/Stesstest_overview.jpg)](https://postimg.org/image/5yhqo2evd/) 

### Configure
Assuming you add your tasks as follows
```properties
iguana.cc.tasks=stresstest,...
```

you can define the stresstest as follows

```properties
stresstest.class=org.aksw.iguana.tp.tasks.impl.stresstest.Stresstest
stresstest.constructorArgs=...
```
#### Constructor Parameters
The following arguments can be added

| Parameter | Example | Value | Description | Prohibitive Parameters |
| --- | --- | --- | --- | --- |
| timeLimit | `stresstestArg.timeLimit=360000` | Long | The time limit the stresstest took in ms | noOfQueryMixes |
| noOfQueryMixes | `stresstestArg.noOfQueryMixes=1000` | Long | The no of quer mixes the stresstest should be end after | timeLimit |
| warmupTime | `stresstestArg.warmupTime=60000` | Long | The warmup time before the task will be executed in ms | - |
| warmupQueries | `stresstestArg.warmupQueries=warmupQueries.txt` | filename | The queries for the warmup (one query per line) | - |
| warmupUpdates | `stresstestArg.warmupUpdates=warmupUpdates.txt` | file/pathname | The updates for the warmup (either a path with updates/file or updates/line as file | - |
| queryHandler | `stresstestArg.queryHandler=org.aksw.iguana.tp.query.impl.InstancesQueryHandler` | String Array | see QueryHandler | - |
| workers | `stresstestArg.workers=workerConfig1, workerConfig2` | String Array of Worker Configuratios to use (one string is a variable to another String array) | The Worker Configuratiosn which should be used (see SPARQLWorker and UPDATEWorker Configuration) | - |

##### QueryHandler
The QueryHandler will be a String Array where the first parameter is the class name of the queryHandler and the second to last are the constructor arguments.

There are two implemented Query Handlers at the moment
* InstancesQueryHandler: org.aksw.iguana.tp.query.impl.InstancesQueryHandler
* PatternQueryHandler: org.aksw.iguana.tp.query.impl.PatternQueryHandler

the PatternQueryHandler needs one argument: the reference endpoint where the handler can exchange the %%v%% v ariables
with real uris -> no queries with results>0 


##### SPARQLWorker Configuration

The SPARQL Worker needs the following order as construction arguments. 

1. No Of Workers
2. "org.aksw.iguana.tp.tasks.impl.stresstest.worker.impl.SPARQLWorker"
3. time out in ms
4. the file name containing queries
5. Fixed Simulated Latency: Will simulate a fixed network latency before each query
6. Gaussian Simulated latency: Will simulate a network latency before each query

Example:

```properties
sparqlConfig1=16, "org.aksw.iguana.tp.tasks.impl.stresstest.worker.impl.SPARQLWorker", 180000, queries.txt, 1000, 500
```

This will create 16 SPARQL Worker with a 180s timeout. 
The worker uses the queries stated in the queries.txt file. 
Before each query a latency will be wait. 
The latency will be calculated as follows: 1000ms + Random.gaussian(500)

##### UPDATEWorker Configuration

The UPDATE Worker needs the following order as construction arguments. 

1. No Of Workers
2. "org.aksw.iguana.tp.tasks.impl.stresstest.worker.impl.SPARQLWorker"
3. time out in ms
4. the file name containing queries
5. Fixed Simulated Latency: Will simulate a fixed network latency before each query
6. Gaussian Simulated latency: Will simulate a network latency before each query
7. Timer Strategy: see below
8. Update Strategy: see below

Timer Strategy: The possible strategies
NONE: updates will be executed immediately after another
FIXED: a fixed value in ms will be waited before the next update query (needs timeLimit)
DISTRIBUTED: the updates will be equally distributed over the time limit of the task (needs timeLimit)


Update Stratagy:  The possible update strategies which can be used to sort the Iguana update files 
 * NONE: no sortation
 * ALL_ADDING_FIRST: all files which should be added will be executed before the files which removes. The added (resp. removed) files will be ordered according their numbers.
 * ALL_REMOVING_FIRST: same as ALL_ADDING_FIRST but first all removing files.
 * ADD_REMOVE: will be sorted by the numbers first, and the add file before the remove file. f.e. 1.added.sparql before 1.removed.sparql but latter one before 2.added.sparql
 * REMOVE_ADD: same as ADD_REMOVE but the remove file before the add file


Example:

```properties
updateConfig1=1, "org.aksw.iguana.tp.tasks.impl.stresstest.worker.impl.UPDATEWorker", 180000, updates/, 1000, 500, NONE, NONE
```

This will create 1 UPDATE Worker with a 180s timeout. 
The worker uses the files as updates stated in the updates folder. 
Before each update a latency will be wait. 
The latency will be calculated as follows: 1000ms + Random.gaussian(500)

Further on no Timer Strategy and no UPDATE Strategy will be used 

##### CLIWorker Configuration

The CLIWorker is similar to the SPARQLWorker except that the connections has to be a script like the following:

```
connection0.name = TripleStore-Name
connection0.service = /path/to/triplestore/query-script.sh -q "$QUERY$" -u $USER$ -p $PASSWORD$
connection0.update.service = %CURRENTLY NOT SUPPORTED
connection0.user = dba
connection0.password = dba
iguana.cc.connections = connection0

```

$USER$ and $PASSWORD$ can be used, they will be exchanged if provided. $QUERY$ will be exchanged using the actual plain query. Alternatively $ENCODEDQUERY$ can be used to use an URL valid encoded Query. 

The constructions are likewise the SPARQLWorker except the class

1. No Of Workers
2. "org.aksw.iguana.tp.tasks.impl.stresstest.worker.impl.CLIWorker"
3. time out in ms
4. the file name containing queries
5. Fixed Simulated Latency: Will simulate a fixed network latency before each query
6. Gaussian Simulated latency: Will simulate a network latency before each query


##### CLIInputWorker Configuration

The CLIInputWorker is similar to the CLIWorker except instead of using an expect an exit cmd script it will be started once and then will be queried using the command line input. 

```
connection0.name = TripleStore-Name
connection0.service = /path/to/triplestore/store-script.sh -dataset dataset.nt $
connection0.update.service = %CURRENTLY NOT SUPPORTED
connection0.user = dba
connection0.password = dba
iguana.cc.connections = connection0

```

It expects next to the CLIWorker constructors two more arguments. 
First the initialLoadFinished which is a String that indicates the store is ready to be queried. 
F.e. if a store has to be loaded using the cli as soon as the store outputs a message like "345 triples were loaded."
the initial load finished string can be "triples were loaded". Iguana will check if the cli output will contain the line. It does not need to match completely. 
The second argument is a String that indicates the query execution print all results. 
f.e. 

"?s, ?p"

"1, 2"

query finished in 0.12 seconds

A CSV or TSV is expected using a header.

1. No Of Workers
2. "org.aksw.iguana.tp.tasks.impl.stresstest.worker.impl.CLIWorker"
3. time out in ms
4. the file name containing queries
5. Fixed Simulated Latency: Will simulate a fixed network latency before each query
6. Gaussian Simulated latency: Will simulate a network latency before each query
7. initial load finished: String that indicates the store is ready to be queried
8. query execution finished: String that indicates the query is finished

#### Example 
```properties
stresstest.constructorArgs=stresstestArg.timeLimit,stresstestArg.warmupTime,stresstestArg.warmupQueries,stresstestArg.warmupUpdates,stresstestArg.workers,stresstestArg.queryHandler

stresstest.class=org.aksw.iguana.tp.tasks.impl.stresstest.Stresstest

#end restricition
stresstestArg.timeLimit=360000
#stresstestArg.noOfQueryMixes=1000

#warmup
stresstestArg.warmupTime=60000
stresstestArg.warmupQueries=warmupQueries.txt
stresstestArg.warmupUpdates=warmupUpdates.txt

stresstestArg.workers=sparqlConfig1, sparqlConfig2, updateConfig1
sparqlConfig1=10, "org.aksw.iguana.tp.tasks.impl.stresstest.worker.impl.SPARQLWorker", 180000, queries.txt, 1000, 500
sparqlConfig2=6, "org.aksw.iguana.tp.tasks.impl.stresstest.worker.impl.SPARQLWorker", 180000, queries2.txt, 0, 0
updateConfig1=1, "org.aksw.iguana.tp.tasks.impl.stresstest.worker.impl.UPDATEWorker", 180000, updates/, 1000, 500, NONE, NONE

stresstestArg.queryHandler=org.aksw.iguana.tp.query.impl.InstanceBasedQueryHandler
# or if your Query handler has Constructor Arguments
# stresstestArg.queryHandler=org.example.com.MyQueryHandler, arg1, arg2,...
```