To create a QueryHandler create a Class as follows

```java
package org.example.myquery.MyQueryhandler

import org.aksw.iguana.tp.query.AbstractWorkerQueryHandler;
import org.aksw.iguana.tp.tasks.impl.stresstest.worker.Worker;


public class MyQueryHandler extends AbstractWorkerQueryHandler {
    
     public MyQueryHandler(LinkedList<Worker> workers) {
	 super(workers);
     }
}
```

If you need constructor arguments, add them, but let the workers list at the beginning. 
All arguments must be of  String.class. (You can easily convert them back to other datatypes.)

Now add the following two methods
```java
...
	@Override
	protected File[] generateSPARQL(String queryFileName) {
             //TODO fill me with something
	}

	@Override
	protected File[] generateUPDATE(String updatePath) {
             //TODO fill me with something
	}
...
```

The abstract query handler will diverge between a SPARQL worker and an UPDATE Worker and uses only your two methods for either generating sparql queries or update queries. 

Now fill the two methods on how you want to generate Updates/SPARQL Queries et voila.
