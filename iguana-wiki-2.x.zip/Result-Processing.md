[![RP Workflow](https://s1.postimg.org/99u19ygx4f/RP_workflow.png)](https://postimg.org/image/92qteiuror/)

The Result Processor will be started as a standalone module. 

It opens a RabbitMQ Consumer and will then wait for an Experiment Task Start Tag. 
This tag indicates that the core started a Task and the Result Processor has to prepare itself for the arriving execution results. 

Every Result which was executed inside the core will be send to the Result Processor which then will add the results to the defined metrics (KPIs). 
The Metrics will then process the results and save them according to their definition. 

If the Experiment Task is finished the Result Processor will receive a Experiment Task End Tag and will close the Metrics.
The generated results of the metrics will then be send to the Storages which are defined

The Storages will then save the results according to their definition. 
Further on they will save all the Meta Data the actual Task provides.
(e.g. The number of one query mix)

### Metrics
The implemented Metrics are

* **QMPH:**  Query Mixes Per Hour (Will calculate the Query Mixes per Hour for one Object (e.g. One SPARQL Worker))
* **QPS:**   Queries Per Seconds (Will calculate the Queries per Second, successess and failed queries for one Object (e.g. One SPARQL Worker))
* **EQE:**   Each Query Execution (Will add every query execution to the storage)
* **NoQPH:** Number of Queries per Hour (Will calculate the number of queries which could be executed in total)

If you want to add your own Metric (KPI) solution pleas check the how to extend Metrics page

#### QMPH
_What will be saved_

_Triple Based Storage_
[![qmph.png](https://s20.postimg.org/48l7ztjv1/qmph.png)](https://postimg.org/image/ofyns4hc9/)

#### QPS
_What will be saved_

_Triple Based Storage_
[![qps.png](https://s20.postimg.org/yq12re231/qps.png)](https://postimg.org/image/irsd197ux/)

#### EQE
_What will be saved_

_Triple Based Storage_
[![eqe.png](https://s20.postimg.org/w8pbk42r1/eqe.png)](https://postimg.org/image/rzklhxzhl/)

#### NoQPH
_What will be saved_

_Triple Based Storage_
[![noqph.png](https://s20.postimg.org/mbear17zx/noqph.png)](https://postimg.org/image/ju2jjro3d/)

### Storages
The implemented Storages are

* **TriplestoreStorage:** Will add all results and meta data into a provided triple store
* **NTFileStorage:** Will add all results and meta data into an NTriples file (semantically same as triplestore storage)
* **FileStorage:** Will save all results as a Folder/File Structure as CSV Files. 

If you want to add your own Storage solution pleas check the how to extend Storages page.

#### File Storage
_Overview of Structure_
[![folder.png](https://s20.postimg.org/lymwkui0d/folder.png)](https://postimg.org/image/ofyns41wp/)

_CSV File Structure_
[![file.png](https://s20.postimg.org/scbzo4ph9/file.png)](https://postimg.org/image/tem66o8ah/)

_Meta Data Input_

_Data Input_

#### Triple Based Storage
_Overview of Structure_
[![image.png](https://s20.postimg.org/t1us0hal9/image.png)](https://postimg.org/image/evf158zq1/)

_Meta Data Input_

_Data Input_