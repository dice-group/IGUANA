### Welcome to the Iguana wiki!

* If you want to know how to install and start Iguana please have a look at [Install-and-Start-Iguana](Install-and-Start-Iguana)
* Check into the [Architecture](architecture) to get a better understanding on how Iguana works
* [Configuration](config) will tell you the different conifguration options
* [JavaDoc](http://iguana-benchmark.eu/javadoc/index.html) will send you directly to the JavaDoc

For the modules
* [Core](core) will show you how the core works
* [Result Processor](Result-Processor) will show you how the result processing works
* [Web Frontend](Web) will show you how to use the webfrontend.

For Tutorials you can visit

* [Execute DBPSB 2012](Tutorial-DBPSB-2012)
* [Execute FEASIBLE](Tutorial-FEASIBLE-2017)

And if you want to know How To Extend Iguana for your needs, the following things are extandable natively:

* [Tasks](Extend-Tasks)
* [Data Generator](Extend-DataGenerator)
* [Query Handler](Extend-QueryHandler)
* [Metrics (KPIs)](Extend-Metrics)
* [Storages](Extend-Storages)


Have exciting Evaluations!