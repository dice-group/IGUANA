This page will show you how to configure the modules as well as how to create an Iguana Config which then can be executed with Iguana.

## Configure Modules
### Core

You can set the rabbitMQ Host name.


To define the rabbitMQ Host please add the following to the properties
```properties
iguana.consumer.host=localhost
```

### Web
You can set the rabbitMQ Host name and the templates with sparql queries to use

to define a template go into the directory src/main/resources and open the templates.properties file
add a template with
```properties
iguana.sparql.templates.YOUR_TEMPLATE_NAME=YOUR SPARQL QUERY
```

To define the rabbitMQ Host please add the following to the properties
```properties
iguana.consumer.host=localhost
```

### Result Processor
You can set the rabbitMQ Host name, the metrics which should be calculated and saved
as well as how and where to save the results

Further on if you want to use the live viewing option of the web controller you have to add
```properties
iguana.rp.useLive=true 
```
to define which metrics should be used simply add the following line
to your properites
```properties
iguana.rp.metrics=metric1, metric2, ...
```
To define metric1, metric2 and so on simply add the following line
```properties
metric1.class=org.aksw.iguana.rp.metrics.impl.QMPHMetric
```

The following classes refer to the following Metrics

* QPS:	 org.aksw.iguana.rp.metrics.impl.QPSMetric
  
* QMPH:	 org.aksw.iguana.rp.metrics.impl.QMPHMetric  

* NoQPH: org.aksw.iguana.rp.metrics.impl.NoQPHMetric

* EQE:	 org.aksw.iguana.rp.metrics.impl.EachQueryMetric


To define the storages which should be used, add the following line
to your properties
```properties
iguana.rp.storages=storage1, storage2,...
```
To define the Storage please add the following
```properties
storage1.class=org.aksw.iguana.rp.storage.impl.TriplestoreStorage
storage1.constructorArgs=http://localhost:9999/blazegraph/sparql, http://localhost:9999/blazegraph/sparql
```

The following Classes refer to the following Storages

* TriplestoreStorage:	org.aksw.iguana.rp.storage.impl.TriplestoreStorage
	(You have to at least specify the endpoint and updateEndpoint of the triple store in the constructor arguments)

* FileStorage:		org.aksw.iguana.rp.storage.impl.FileStorage
	(optional: you can define the root directory of the stored CSV files)

* NTFileStorage:	org.aksw.iguana.rp.storage.impl.NTFileStorage
	(optional: you can specify the Ntriple file name)

For Further Information to the constructor Arguments, 
visit the JavaDoc: http://iguana-benchmark.eu/javadoc/index.html



To define the rabbitMQ Host please add the following to the properties

```properties
iguana.consumer.host=localhost
```

All three (iguana.rp.consumer, iguana.rp.metrics, iguana.rp.storages) 
have to be stated in the properties file somehow.

## Iguana Config
To create an Iguana Config use either the web wizard or follow this construction.

Create a file called iguana.suite

To add connections, you have to add the following lines to the file:
```properties
iguana.cc.connections=connection1,connection2,...connectionN
```
(you can change the connection1 variable to what ever suites you)
Now you only have to define your connections which you specified (connection1,...connectioN). 
You can do this by adding the following to the file
```properties
# The Readable Name you want to give the triple store
connection1.name=Blazegraph
# The sparql Endpoint of the triple store
connection1.service=http://localhost:9999/blazegraph/sparql
# The update Endpoint of the triple store (this is optional, if not provided Iguana will use the service address)
connection1.update.service=http://localhost:9999/blazegraph/sparql
```

optional you can add a user and a password for the connection, which will be used for updates
```properties
connection1.user=UserName
connection1.password=secret
```
Do this for all your connections.

Next you will add your datasets. 
Do this by adding the line (you can change the dataset1 variable to what ever suites you)
```properties
iguana.cc.datasets=dataset1,dataset2,...datasetN
```

Now define the specified datasets as follows:
```properties
# The Readable Name you want to give your Dataset
dataset1.name=DBpedia 100 percent
```

If you are using a data generator you can add the configuration by adding this:
```properties
# The dataGenerator class name
dataset1.dg.class=org.example.datagenerator.MyDataGenerator
# The String Array constructor arguments
dataset1.constructorArgs=arg1, arg2, arg3,...argN
```

Now you can add all the Tasks you want.
The same procedure as previously, add the tasks as variables and define the variables
```properties
iguana.cc.tasks=task1,task2,task3,...taskN

task1.class=org.example.task.MyTask
task1.constructorArgs=arg1, arg2, arg3,... argN
arg2=2000
arg3=arg3.1, arg3.2
...
```

Check the tasks for specific configuration.

Further on you can define Pre and Post Script Hooks. 
This means the scripts will be execute right before (resp. after) the task executes. 

You can use this to change the dataset, or start and stop the triple store. 

Iguana will add the following as parameters (in the following order)
* dataset ID, which is executed currently
* connection ID, which is executed currently
* task ID, which is executed currently

Define it by adding the following lines
```properties
# Pre Hook
script.hook.pre=preScript.sh
# Post Hook
script.hook.post=postScript.sh
```