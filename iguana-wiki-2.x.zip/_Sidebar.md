#### Version 2
**Getting Started**

[Install-and-Start-Iguana](Install-and-Start-Iguana)

***
**Documentation**

[Architecture](architecture)

[Configuration](config)
* [Stresstest](stresstest)

[JavaDoc](http://iguana-benchmark.eu/javadoc/index.html)

***Modules***
* [Core](core)
* [Result Processing](Result-Processing)
* [Web Frontend](web)
***
**Tutorials**

[Execute DBPSB 2012](Tutorial-DBPSB-2012)

[Execute FEASIBLE](Tutorial-FEASIBLE-2017)
***
**How To Extend**

[Tasks](Extend-Tasks)

[Data Generator](Extend-DataGenerator)

[Query Handler](Extend-QueryHandler)

[Metrics (KPIs)](Extend-Metrics)

[Storages](Extend-Storages)

[Obtain Statistics](Obtaining-Statistics)

***
