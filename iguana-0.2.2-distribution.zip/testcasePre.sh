#!/bin/sh
# $1 = DBID
# $2 = PERCENTAGE
# $3 = TESTCASEID
#
echo "$1 $2 $3"
export CATALINA_OPTS="-Xmx16g"
#VIRTUOSO
if [ "$1" = "virtuoso" ]
then
echo "Stopping Virtuoso Instance"
ps -ef | grep "/ose/7.0.0./bin/virtuoso-t" | grep -v grep | awk '{print $2}' | xargs kill -9
echo "Copying backup folder"
rm -rf ~/iguana-benchmark/db/
mkdir ~/iguana-benchmark/db/
if [ "$2" = "1.0" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_100/db/* ~/iguana-benchmark/db/
elif [ "$2" = "0.5" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_50/db/* ~/iguana-benchmark/db/
elif [ "$2" = "0.2" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_20/db/* ~/iguana-benchmark/db/
elif [ "$2" = "0.1" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_10/db/* ~/iguana-benchmark/db/
fi
echo "Starting Virtuoso Instance"
/opt/virtuoso/bin/virtuoso-t +configfile ~/iguana-benchmark/virtuoso.ini
fi
#BLAZEGRAPH
if [ "$1" = "blazegraph" ]
then
echo "Stopping Blazegraph Instance"
ps -ef | grep bigdata | grep -v grep | awk '{print $2}' | xargs kill -9
echo "Copying backup folder"
rm ~/iguana-benchmark/teststores/blazegraph/bigdata.jnl
if [ "$2" = "1.0" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_100/bigdata.jnl ~/iguana-benchmark/teststores/blazegraph/
elif [ "$2" = "0.5" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_50/bigdata.jnl ~/iguana-benchmark/teststores/blazegraph/
elif [ "$2" = "0.2" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_20/bigdata.jnl ~/iguana-benchmark/teststores/blazegraph/
elif [ "$2" = "0.1" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_10/bigdata.jnl ~/iguana-benchmark/teststores/blazegraph/
fi
echo "Starting Blazegraph Instance"
java -server -jar -Xmx16g ~/iguana-benchmark/teststores/blazegraph/bigdata-1.5.2-bundled.jar >  blazegraph.out 2>&1 &
fi
#BIGOWLIM
if [ "$1" = "owlim" ]
then
echo "Stopping owlim Instance"
/opt/tomcat/bin/shutdown.sh
echo "Copying backup folder"
rm -rf ~/.aduna/openrdf-sesame/repositories/owlim
mkdir ~/.aduna/openrdf-sesame/repositories/owlim
if [ "$2" = "1.0" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_100/SESAME/owlim/* ~/.aduna/openrdf-sesame/repositories/owlim
elif [ "$2" = "0.5" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_50/SESAME/owlim/* ~/.aduna/openrdf-sesame/repositories/owlim
elif [ "$2" = "0.2" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_20/SESAME/owlim/* ~/.aduna/openrdf-sesame/repositories/owlim
elif [ "$2" = "0.1" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_10/SESAME/owlim/* ~/.aduna/openrdf-sesame/repositories/owlim
fi
echo "Starting owlim Instance"
/opt/tomcat/bin/startup.sh &
fi
#SESAME
if [ "$1" = "sesame" ]
then
echo "Stopping Sesame Instance"
/opt/tomcat/bin/shutdown.sh
echo "Copying backup folder"
rm -rf ~/.aduna/openrdf-sesame/repositories/SYSTEM
mkdir ~/.aduna/openrdf-sesame/repositorie/SYSTEM
if [ "$2" = "1.0" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_100/SESAME/SYSTEM/* ~/.aduna/openrdf-sesame/repositories/SYSTEM
elif [ "$2" = "0.5" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_50/SESAME/SYSTEM/* ~/.aduna/openrdf-sesame/repositories/SYSTEM
elif [ "$2" = "0.2" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_20/SESAME/SYSTEM/* ~/.aduna/openrdf-sesame/repositories/SYSTEM
elif [ "$2" = "0.1" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_10/SESAME/SYSTEM/* ~/.aduna/openrdf-sesame/repositories/SYSTEM
fi
echo "Starting sesame Instance"
/opt/tomcat/bin/startup.sh &
fi
#FUSEKI
if [ "$1" = "fuseki" ]
then
echo "Stopping fuseki Instance"
ps -ef | grep fuseki-server | grep -v grep | awk '{print $2}' | xargs kill -9
echo "Copying backup folder"
rm -rf ~/iguana-benchmark/teststores/apache-jena-fuseki-2.3.0/DB/
mkdir ~/iguana-benchmark/teststores/apache-jena-fuseki-2.3.0/DB/
if [ "$2" = "1.0" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_100/DB/* ~/iguana-benchmark/teststores/apache-jena-fuseki-2.3.0/DB/
elif [ "$2" = "0.5" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_50/DB/* ~/iguana-benchmark/teststores/apache-jena-fuseki-2.3.0/DB/
elif [ "$2" = "0.2" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_20/DB/* ~/iguana-benchmark/teststores/apache-jena-fuseki-2.3.0/DB/
elif [ "$2" = "0.1" ]
then
cp -r ~/iguana-benchmark/backup/dbpedia_new_10/DB/* ~/iguana-benchmark/teststores/apache-jena-fuseki-2.3.0/DB/
fi
echo "Starting fuseki Instance"
cd ~/iguana-benchmark/teststores/apache-jena-fuseki-2.3.0/
nohup ./fuseki-server --update --loc=DB /ds &
fi
echo "finished"
